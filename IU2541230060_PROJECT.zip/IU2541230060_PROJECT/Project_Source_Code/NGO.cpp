#include "NGO.h"
#include "FileManager.h"
#include "Utils.h"
#include <iostream>
#include <string>
using namespace std;

// ---------------------------------------------------------------
//  Generic helpers. They work on any Store<T> where T derives from
//  Record, and call display()/serialize() through a Record pointer
//  (runtime polymorphism).
// ---------------------------------------------------------------
template <typename T>
static void showAll(const Store<T>& s, const string& title) {
    cout << "  --- " << BLUE << title << " (" << s.size() << ")" << RESET << " ---" << endl;
    for (int i = 0; i < s.size(); i++) {
        const Record* r = &s.at(i);
        r->display();                       // correct derived version runs
    }
}

template <typename T>
static int searchStore(const Store<T>& s, const string& key) {
    string k = toLower(key);
    int found = 0;
    for (int i = 0; i < s.size(); i++) {
        const Record* r = &s.at(i);
        string text = toLower(r->serialize());
        string body = text.substr(text.find('|') + 1);     // skip the id field
        bool byId = (to_string(r->getId()) == key);
        if (byId || body.find(k) != string::npos) {
            r->display();
            found++;
        }
    }
    return found;
}

// ---------------------------------------------------------------
NGO::NGO() : volunteers(4), events(4), skills(4), assignments(4), dirty(false) {}
NGO::~NGO() {}        // the Store<T> members free their own memory

// ----------------------- core operations -----------------------
int NGO::addVolunteer(const string& name, const string& phone, const string& skillList) {
    validateName(name);
    validatePhone(phone);
    validateText(skillList, "Skills");
    int id = volunteers.nextId();
    volunteers.add(Volunteer(id, name, phone, skillList));
    dirty = true;
    return id;
}

int NGO::addEvent(const string& name, const string& date) {
    validateText(name, "Event name");
    validateDate(date);
    int id = events.nextId();
    events.add(Event(id, name, date));
    dirty = true;
    return id;
}

int NGO::addSkill(const string& name, int level) {
    validateText(name, "Skill name");
    if (level < 1 || level > 3) throw ValidationException("Level must be 1, 2 or 3.");
    for (int i = 0; i < skills.size(); i++)
        if (toLower(skills.at(i).getName()) == toLower(name))
            throw AppException("Skill already exists.");
    int id = skills.nextId();
    skills.add(Skill(id, name, level));
    dirty = true;
    return id;
}

// Main transaction: assign a volunteer to an event.
int NGO::assignVolunteer(int volunteerId, int eventId, const string& role) {
    validateText(role, "Role");                                   // (1) role text

    int vi = volunteers.indexOfId(volunteerId);                   // (2) IDs must exist
    if (vi < 0) throw AppException("Volunteer ID not found.");
    int ei = events.indexOfId(eventId);
    if (ei < 0) throw AppException("Event ID not found.");

    const string& newDate = events.at(ei).getDate();
    for (int i = 0; i < assignments.size(); i++) {
        const Assignment& a = assignments.at(i);
        if (a.getVolunteerId() != volunteerId) continue;
        if (a.getEventId() == eventId)                            // (3) duplicate
            throw AppException("Volunteer is already assigned to this event.");
        int other = events.indexOfId(a.getEventId());
        if (other >= 0 && events.at(other).getDate() == newDate)  // (4) same-date clash
            throw AppException("Volunteer is already booked for another event on this date.");
    }

    Assignment a;                                                 // (5) create + store
    a.setId(assignments.nextId());
    a.setName("Assignment");
    a.assign(volunteerId, eventId, role);
    assignments.add(a);
    dirty = true;
    return a.getId();
}

static void removeAssignmentsWhere(Store<Assignment>& st, bool byVolunteer, int id) {
    for (int i = st.size() - 1; i >= 0; i--) {
        int key = byVolunteer ? st.at(i).getVolunteerId() : st.at(i).getEventId();
        if (key == id) st.removeAt(i);
    }
}

void NGO::deleteVolunteer(int id) {
    int i = volunteers.indexOfId(id);
    if (i < 0) throw AppException("Record not found.");
    volunteers.removeAt(i);
    removeAssignmentsWhere(assignments, true, id);       // cascade
    dirty = true;
}

void NGO::deleteEvent(int id) {
    int i = events.indexOfId(id);
    if (i < 0) throw AppException("Record not found.");
    events.removeAt(i);
    removeAssignmentsWhere(assignments, false, id);      // cascade
    dirty = true;
}

void NGO::deleteSkill(int id) {
    int i = skills.indexOfId(id);
    if (i < 0) throw AppException("Record not found.");
    skills.removeAt(i);
    dirty = true;
}

void NGO::deleteAssignment(int id) {
    int i = assignments.indexOfId(id);
    if (i < 0) throw AppException("Record not found.");
    assignments.removeAt(i);
    dirty = true;
}

// ----------------------------- menus ----------------------------
void NGO::showMainMenu() const {
    cout << "\n" << BLUE << "=========== NGO VOLUNTEER MANAGEMENT ===========" << RESET << endl;
    cout << " 1. Add Record" << endl;
    cout << " 2. Display Records" << endl;
    cout << " 3. Search Record" << endl;
    cout << " 4. Update Record" << endl;
    cout << " 5. Delete Record" << endl;
    cout << " 6. Main Transaction (Assign Volunteer to Event)" << endl;
    cout << " 7. Report" << endl;
    cout << " 8. Save / Load" << endl;
    cout << " 9. Exit" << endl;
}

void NGO::menuAdd() {
    cout << "\n  Add which record type?" << endl;
    cout << "   1. Volunteer" << endl;
    cout << "   2. Event" << endl;
    cout << "   3. Skill" << endl;
    int t = readInt("  Choice: ", 1, 3);

    if (t == 1) {
        string name   = readName("  Name   : ");
        string phone  = readPhone("  Phone (10 digits): ");
        string skillL = readText("  Skills (comma separated): ", "Skills");
        int id = addVolunteer(name, phone, skillL);
        cout << GREEN << "  Volunteer added with ID " << id << "." << RESET << endl;
    } else if (t == 2) {
        string name = readText("  Event name: ", "Event name");
        string date = readDate("  Date (DD/MM/YYYY): ");
        int id = addEvent(name, date);
        cout << GREEN << "  Event added with ID " << id << "." << RESET << endl;
    } else {
        string name = readText("  Skill name: ", "Skill name");
        int level   = readInt("  Level (1=Beginner, 2=Intermediate, 3=Expert): ", 1, 3);
        int id = addSkill(name, level);
        cout << GREEN << "  Skill added with ID " << id << "." << RESET << endl;
    }
}

void NGO::menuDisplay() {
    cout << "\n  Display which record type?" << endl;
    cout << "   1. Volunteer" << endl;
    cout << "   2. Event" << endl;
    cout << "   3. Skill" << endl;
    cout << "   4. Assignment" << endl;
    int t = readInt("  Choice: ", 1, 4);
    cout << endl;
    if (t == 1)      showAll(volunteers, "Volunteers");
    else if (t == 2) showAll(events, "Events");
    else if (t == 3) showAll(skills, "Skills");
    else             showAll(assignments, "Assignments");
}

void NGO::menuSearch() {
    cout << "\n  Search which record type?" << endl;
    cout << "   1. Volunteer" << endl;
    cout << "   2. Event" << endl;
    cout << "   3. Skill" << endl;
    cout << "   4. Assignment" << endl;
    int t = readInt("  Choice: ", 1, 4);
    string key = readText("  Enter ID or keyword: ", "Keyword");
    cout << endl;

    int n = 0;
    if (t == 1)      n = searchStore(volunteers, key);
    else if (t == 2) n = searchStore(events, key);
    else if (t == 3) n = searchStore(skills, key);
    else             n = searchStore(assignments, key);

    if (n == 0) cout << "  No matching record found." << endl;
    else        cout << "  " << n << " record(s) found." << endl;
}

void NGO::menuUpdate() {
    cout << "\n  Update which record type?" << endl;
    cout << "   1. Volunteer" << endl;
    cout << "   2. Event" << endl;
    cout << "   3. Skill" << endl;
    cout << "   4. Assignment (role only)" << endl;
    int t = readInt("  Choice: ", 1, 4);
    int id = readInt("  Enter ID to update: ", 1, 999999);

    if (t == 1) {
        int i = volunteers.indexOfId(id);
        if (i < 0) throw AppException("Record not found.");
        string name   = readName("  New name   : ");
        string phone  = readPhone("  New phone (10 digits): ");
        string skillL = readText("  New skills (comma separated): ", "Skills");
        volunteers.at(i).setName(name);
        volunteers.at(i).setPhone(phone);
        volunteers.at(i).setSkills(skillL);
    } else if (t == 2) {
        int i = events.indexOfId(id);
        if (i < 0) throw AppException("Record not found.");
        string name = readText("  New event name: ", "Event name");
        string date = readDate("  New date (DD/MM/YYYY): ");
        events.at(i).setName(name);
        events.at(i).setDate(date);
    } else if (t == 3) {
        int i = skills.indexOfId(id);
        if (i < 0) throw AppException("Record not found.");
        string name = readText("  New skill name: ", "Skill name");
        int level   = readInt("  New level (1-3): ", 1, 3);
        skills.at(i).setName(name);
        skills.at(i).setLevel(level);
    } else {
        int i = assignments.indexOfId(id);
        if (i < 0) throw AppException("Record not found.");
        string role = readText("  New role: ", "Role");
        assignments.at(i).setRole(role);
    }
    dirty = true;
    cout << GREEN << "  Record updated." << RESET << endl;
}

void NGO::menuDelete() {
    cout << "\n  Delete which record type?" << endl;
    cout << "   1. Volunteer" << endl;
    cout << "   2. Event" << endl;
    cout << "   3. Skill" << endl;
    cout << "   4. Assignment" << endl;
    int t = readInt("  Choice: ", 1, 4);
    int id = readInt("  Enter ID to delete: ", 1, 999999);

    if (t == 1)      deleteVolunteer(id);
    else if (t == 2) deleteEvent(id);
    else if (t == 3) deleteSkill(id);
    else             deleteAssignment(id);
    cout << GREEN << "  Record deleted." << RESET << endl;
}

void NGO::menuTransaction() {
    if (volunteers.size() == 0 || events.size() == 0)
        throw AppException("Add at least one volunteer and one event first.");

    cout << "\n  === ASSIGN VOLUNTEER TO EVENT ===\n" << endl;
    showAll(volunteers, "Volunteers");
    cout << endl;
    showAll(events, "Events");

    int vId = readInt("  Volunteer ID: ", 1, 999999);
    int eId = readInt("  Event ID    : ", 1, 999999);
    string role = readText("  Role (e.g. Coordinator, Cook, Driver): ", "Role");

    int id = assignVolunteer(vId, eId, role);
    cout << GREEN << "  Assignment created with ID " << id << "." << RESET << endl;
}

void NGO::report() const {
    cout << "\n  ========== NGO VOLUNTEER REPORT ==========" << endl;
    cout << "  Total volunteers : " << volunteers.size() << endl;
    cout << "  Total events     : " << events.size() << endl;
    cout << "  Total skills     : " << skills.size() << endl;
    cout << "  Total assignments: " << assignments.size() << endl;

    // volunteers per event
    for (int e = 0; e < events.size(); e++) {
        const Event& ev = events.at(e);
        cout << "\n  Event " << ev.getId() << ": " << ev.getName()
             << " (" << ev.getDate() << ")" << endl;
        bool any = false;
        for (int a = 0; a < assignments.size(); a++) {
            const Assignment& as = assignments.at(a);
            if (as.getEventId() != ev.getId()) continue;
            int vi = volunteers.indexOfId(as.getVolunteerId());
            if (vi < 0) continue;
            cout << "     - " << volunteers.at(vi).getName()
                 << " as " << as.getRole() << endl;
            any = true;
        }
        if (!any) cout << "     (no volunteers assigned yet)" << endl;
    }

    // volunteers with no assignment
    cout << "\n  Volunteers with no assignment:" << endl;
    bool idle = false;
    for (int v = 0; v < volunteers.size(); v++) {
        bool used = false;
        for (int a = 0; a < assignments.size(); a++)
            if (assignments.at(a).getVolunteerId() == volunteers.at(v).getId()) {
                used = true;
                break;
            }
        if (!used) {
            cout << "     - " << volunteers.at(v).getName() << endl;
            idle = true;
        }
    }
    if (!idle) cout << "     (none)" << endl;
}

void NGO::menuSaveLoad() {
    cout << "\n  1. Save to file" << endl;
    cout << GREEN << "  2. Load from file (discards unsaved changes)" << RESET << endl;
    int t = readInt("  Choice: ", 1, 2);
    if (t == 1) {
        saveAll();
        cout << GREEN << "  Data saved to Data/ folder." << RESET << endl;
    } else {
        if (dirty) {
            string a = readLine("  You have unsaved changes. Load anyway? (y/n): ");
            if (toLower(a) != "y") { cout << "  Load cancelled." << endl; return; }
        }
        loadAll();
        cout << GREEN << "  Data loaded from Data/ folder." << RESET << endl;
    }
}

// --------------------------- file operations ---------------------------
void NGO::saveAll() {
    FileManager fm("Data");
    fm.save(*this);
    dirty = false;
}

bool NGO::loadAll() {
    FileManager fm("Data");
    bool found = fm.load(*this);
    dirty = false;
    return found;
}

// ------------------------------- main loop -------------------------------
void NGO::run() {
    try {
        if (loadAll())
            cout << GREEN << "  Existing records loaded from Data/ folder." << RESET << endl;
    } catch (AppException& e) {
        cout << RED << "  [File Error] " << e.what() << RESET << endl;
        cout << "  Exiting without changing the data files." << endl;
        return;
    }

    bool running = true;
    while (running) {
        try {
            showMainMenu();
            int choice = readInt("Enter choice: ", 1, 9);
            switch (choice) {
                case 1: menuAdd();         break;
                case 2: menuDisplay();     break;
                case 3: menuSearch();      break;
                case 4: menuUpdate();      break;
                case 5: menuDelete();      break;
                case 6: menuTransaction(); break;
                case 7: report();          break;
                case 8: menuSaveLoad();    break;
                case 9:
                    saveAll();
                    cout << GREEN << "  Data saved. Goodbye!" << RESET << endl;
                    running = false;
                    break;
            }
        } catch (InputClosedException&) {          // Ctrl+D / end of input
            saveAll();
            cout << "\n" << GREEN << "  Input closed. Data saved." << RESET << endl;
            running = false;
        } catch (ValidationException& e) {
            cout << RED << "  [Invalid] " << e.what() << RESET << endl;
        } catch (AppException& e) {
            cout << RED << "  [Error] " << e.what() << RESET << endl;
        }
    }
}
