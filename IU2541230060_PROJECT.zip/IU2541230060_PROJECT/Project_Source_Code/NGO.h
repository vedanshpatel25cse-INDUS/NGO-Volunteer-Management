#ifndef NGO_H
#define NGO_H

#include <string>
#include "Store.h"
#include "Volunteer.h"
#include "Event.h"
#include "Skill.h"
#include "Assignment.h"

class FileManager;

// System class: owns all data and implements every menu option.
class NGO {
private:
    Store<Volunteer>  volunteers;
    Store<Event>      events;
    Store<Skill>      skills;
    Store<Assignment> assignments;
    bool dirty;                       // true when there are unsaved changes

    friend class FileManager;

    void showMainMenu() const;

public:
    NGO();
    ~NGO();

    // ----- core operations -----
    int  addVolunteer(const std::string& name, const std::string& phone,
                      const std::string& skillList);
    int  addEvent(const std::string& name, const std::string& date);
    int  addSkill(const std::string& name, int level);
    int  assignVolunteer(int volunteerId, int eventId, const std::string& role);

    void deleteVolunteer(int id);
    void deleteEvent(int id);
    void deleteSkill(int id);
    void deleteAssignment(int id);

    // ----- menu handlers -----
    void menuAdd();
    void menuDisplay();
    void menuSearch();
    void menuUpdate();
    void menuDelete();
    void menuTransaction();
    void menuSaveLoad();
    void report() const;

    // ----- file operations -----
    void saveAll();
    bool loadAll();

    void run();
};

#endif
