#ifndef UTILS_H
#define UTILS_H

#include <string>
#include <stdexcept>

// ---------- Colours used for console messages ----------
const std::string GREEN = "\033[92m";
const std::string RED   = "\033[91m";
const std::string BLUE  = "\033[94m";
const std::string RESET = "\033[0m";

// ---------- Exception hierarchy ----------
class AppException : public std::runtime_error {
public:
    explicit AppException(const std::string& msg) : std::runtime_error(msg) {}
};

class ValidationException : public AppException {
public:
    explicit ValidationException(const std::string& msg) : AppException(msg) {}
};

class InputClosedException : public AppException {
public:
    InputClosedException() : AppException("Input closed.") {}
};

// ---------- Validation helpers (throw ValidationException) ----------
void validateName(const std::string& s);
void validateText(const std::string& s, const std::string& what);
void validatePhone(const std::string& s);
void validateDate(const std::string& s);

// ---------- Input helpers (re-prompt until the input is valid) ----------
std::string readLine(const std::string& prompt);
int         readInt(const std::string& prompt, int lo, int hi);
std::string readName(const std::string& prompt);
std::string readText(const std::string& prompt, const std::string& what);
std::string readPhone(const std::string& prompt);
std::string readDate(const std::string& prompt);

// ---------- String helpers ----------
std::string trim(const std::string& s);
std::string toLower(const std::string& s);

#endif
