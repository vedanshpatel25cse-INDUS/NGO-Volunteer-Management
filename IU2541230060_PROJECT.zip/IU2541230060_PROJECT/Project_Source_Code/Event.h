#ifndef EVENT_H
#define EVENT_H

#include "Record.h"

class Event : public Record {
private:
    std::string date;       // DD/MM/YYYY

public:
    Event();
    Event(int id, const std::string& name, const std::string& date);
    ~Event();

    const std::string& getDate() const;
    void setDate(const std::string& d);

    void display() const;
    std::string serialize() const;
    void deserialize(const std::string& line);
    std::string typeName() const;
};

#endif
