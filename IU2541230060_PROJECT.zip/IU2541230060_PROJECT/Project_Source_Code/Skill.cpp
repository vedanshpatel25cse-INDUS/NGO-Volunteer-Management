#include "Skill.h"
#include "Utils.h"
#include <iostream>
#include <iomanip>
#include <cstdlib>
using namespace std;

Skill::Skill() : Record(), level(1) {}
Skill::Skill(int id, const string& name, int level) : Record(id, name), level(level) {}
Skill::~Skill() {}

int Skill::getLevel() const { return level; }
void Skill::setLevel(int l) { level = l; }

string Skill::levelName() const {
    if (level == 1) return "Beginner";
    if (level == 2) return "Intermediate";
    return "Expert";
}

void Skill::display() const {
    cout << "  ID: " << left << setw(3) << id
         << " | Skill: " << setw(18) << name
         << " | Level: " << level << " (" << levelName() << ")" << endl;
}

string Skill::serialize() const {
    return to_string(id) + "|" + name + "|" + to_string(level);
}

void Skill::deserialize(const string& line) {
    vector<string> p = split(line);
    if (p.size() != 3) throw AppException("Corrupt skill record");
    id = atoi(p[0].c_str());
    name = p[1];
    level = atoi(p[2].c_str());
    if (id <= 0 || level < 1 || level > 3) throw AppException("Corrupt skill record (bad value)");
}

string Skill::typeName() const { return "Skill"; }
