# NGO Volunteer Management

Console-based C++ application to manage NGO volunteers, skills, events and volunteer-to-event assignments.

- **Enrollment No.:** IU2541230060
- **Student:** Vedansh Patel
- **Subject:** C++ Guided Project (CPP39), Semester 3

## Features
- Add / Display / Search / Update / Delete for Volunteers, Events, Skills and Assignments
- Main transaction: assign a volunteer to an event with a role (rejects duplicates and same-date clashes)
- Report: totals, volunteers per event, volunteers with no assignment
- File handling: data auto-loaded at start and saved at exit (`Data/*.txt`)
- Input validation and exception handling

## OOP concepts used
Classes and objects, encapsulation, constructors/destructors, inheritance (`Record` base class), runtime polymorphism (pure virtual `display/serialize/deserialize`), dynamic memory (`Store<T>` with `new[]`/`delete[]`), file handling, exception handling.

## Project structure
```
Project_Source_Code/
├── main.cpp                  entry point
├── NGO.h / NGO.cpp           system class: menus + main transaction
├── Record.h / Record.cpp     abstract base class
├── Volunteer / Event / Skill / Assignment (.h/.cpp)
├── Store.h                   template dynamic array
├── FileManager.h / .cpp      save / load
├── Utils.h / Utils.cpp       validation, input helpers, exceptions
├── Makefile, build.bat       build scripts
├── Data/                     data files are created here at run time
└── docs/
    ├── UML_Diagrams/         use case, class, 2 sequence diagrams
    └── Screenshots/          sample output screens
```

## Build and run
Linux / macOS:
```
make
./NGOVolunteer
```
Windows (MinGW g++): double-click `build.bat`, or run
```
g++ -std=c++11 main.cpp NGO.cpp FileManager.cpp Record.cpp Volunteer.cpp Event.cpp Skill.cpp Assignment.cpp Utils.cpp -o NGOVolunteer.exe
NGOVolunteer.exe
```
Run the program from this folder so it finds/creates the `Data/` folder.
