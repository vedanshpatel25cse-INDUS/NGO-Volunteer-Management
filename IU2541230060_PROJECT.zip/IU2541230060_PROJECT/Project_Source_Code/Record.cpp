#include "Record.h"
using namespace std;

Record::Record() : id(0), name("") {}
Record::Record(int id, const string& name) : id(id), name(name) {}
Record::~Record() {}

int Record::getId() const { return id; }
const string& Record::getName() const { return name; }
void Record::setId(int newId) { id = newId; }
void Record::setName(const string& newName) { name = newName; }

vector<string> Record::split(const string& line, char sep) {
    vector<string> parts;
    string cur;
    for (size_t i = 0; i < line.size(); i++) {
        if (line[i] == sep) { parts.push_back(cur); cur.clear(); }
        else cur += line[i];
    }
    parts.push_back(cur);
    return parts;
}
