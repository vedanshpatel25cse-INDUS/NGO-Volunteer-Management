#include "FileManager.h"
#include "NGO.h"
#include "Utils.h"
#include <fstream>
#include <string>

#ifdef _WIN32
  #include <direct.h>
  #define MAKE_DIR(d) _mkdir(d)
#else
  #include <sys/stat.h>
  #define MAKE_DIR(d) mkdir(d, 0755)
#endif

using namespace std;

// Writes every record of a store; serialize() is called through a Record*.
template <typename T>
static void saveStore(const string& filename, const Store<T>& s) {
    ofstream out(filename.c_str());
    if (!out) throw AppException("Cannot write file: " + filename);
    for (int i = 0; i < s.size(); i++) {
        const Record* r = &s.at(i);
        out << r->serialize() << "\n";
    }
    if (!out) throw AppException("Error while writing file: " + filename);
}

// Reads a store from a file. A missing file means "empty list".
template <typename T>
static bool loadStore(const string& filename, const string& shortName, Store<T>& s) {
    ifstream in(filename.c_str());
    if (!in) return false;
    string line;
    int lineNo = 0;
    while (getline(in, line)) {
        lineNo++;
        line = trim(line);
        if (line.empty()) continue;
        T item;
        Record* r = &item;
        try {
            r->deserialize(line);
            if (s.indexOfId(item.getId()) >= 0) throw AppException("Duplicate ID");
        } catch (AppException& e) {
            throw AppException(shortName + " (line " + to_string(lineNo) + "): " + e.what());
        }
        s.add(item);
    }
    return true;
}

FileManager::FileManager(const string& dir) : dir(dir) {}
FileManager::~FileManager() {}

string FileManager::path(const string& file) const { return dir + "/" + file; }

void FileManager::makeDir() const { MAKE_DIR(dir.c_str()); }   // ignored if it already exists

void FileManager::save(NGO& ngo) {
    makeDir();
    saveStore(path("volunteers.txt"),  ngo.volunteers);
    saveStore(path("events.txt"),      ngo.events);
    saveStore(path("skills.txt"),      ngo.skills);
    saveStore(path("assignments.txt"), ngo.assignments);
}

bool FileManager::load(NGO& ngo) {
    // Load into a temporary object first, so a corrupt file can never
    // leave the real data half-loaded.
    NGO temp;
    bool any = false;
    any |= loadStore(path("volunteers.txt"),  "volunteers.txt",  temp.volunteers);
    any |= loadStore(path("events.txt"),      "events.txt",      temp.events);
    any |= loadStore(path("skills.txt"),      "skills.txt",      temp.skills);
    any |= loadStore(path("assignments.txt"), "assignments.txt", temp.assignments);

    for (int i = 0; i < temp.assignments.size(); i++) {
        const Assignment& a = temp.assignments.at(i);
        if (temp.volunteers.indexOfId(a.getVolunteerId()) < 0 ||
            temp.events.indexOfId(a.getEventId()) < 0)
            throw AppException("assignments.txt: assignment " + to_string(a.getId()) +
                               " refers to a missing volunteer or event");
    }

    ngo.volunteers.clear();
    ngo.events.clear();
    ngo.skills.clear();
    ngo.assignments.clear();
    for (int i = 0; i < temp.volunteers.size(); i++)  ngo.volunteers.add(temp.volunteers.at(i));
    for (int i = 0; i < temp.events.size(); i++)      ngo.events.add(temp.events.at(i));
    for (int i = 0; i < temp.skills.size(); i++)      ngo.skills.add(temp.skills.at(i));
    for (int i = 0; i < temp.assignments.size(); i++) ngo.assignments.add(temp.assignments.at(i));
    return any;
}
