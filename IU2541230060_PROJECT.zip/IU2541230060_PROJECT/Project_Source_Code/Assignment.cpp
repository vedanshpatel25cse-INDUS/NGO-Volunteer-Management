#include "Assignment.h"
#include "Utils.h"
#include <iostream>
#include <iomanip>
#include <cstdlib>
using namespace std;

Assignment::Assignment() : Record(), volunteerId(0), eventId(0), role("") {}
Assignment::Assignment(int id, int volunteerId, int eventId, const string& role)
    : Record(id, "Assignment"), volunteerId(volunteerId), eventId(eventId), role(role) {}
Assignment::~Assignment() {}

void Assignment::assign(int vId, int eId, const string& r) {
    volunteerId = vId;
    eventId = eId;
    role = r;
}

int Assignment::getVolunteerId() const { return volunteerId; }
int Assignment::getEventId() const     { return eventId; }
const string& Assignment::getRole() const { return role; }
void Assignment::setRole(const string& r) { role = r; }

void Assignment::display() const {
    cout << "  ID: " << left << setw(3) << id
         << " | Volunteer ID: " << setw(3) << volunteerId
         << " | Event ID: " << setw(3) << eventId
         << " | Role: " << role << endl;
}

string Assignment::serialize() const {
    return to_string(id) + "|" + to_string(volunteerId) + "|" + to_string(eventId) + "|" + role;
}

void Assignment::deserialize(const string& line) {
    vector<string> p = split(line);
    if (p.size() != 4) throw AppException("Corrupt assignment record");
    id = atoi(p[0].c_str());
    volunteerId = atoi(p[1].c_str());
    eventId = atoi(p[2].c_str());
    role = p[3];
    name = "Assignment";
    if (id <= 0 || volunteerId <= 0 || eventId <= 0)
        throw AppException("Corrupt assignment record (bad id)");
}

string Assignment::typeName() const { return "Assignment"; }
