#ifndef SKILL_H
#define SKILL_H

#include "Record.h"

class Skill : public Record {
private:
    int level;              // 1 = Beginner, 2 = Intermediate, 3 = Expert

public:
    Skill();
    Skill(int id, const std::string& name, int level);
    ~Skill();

    int getLevel() const;
    void setLevel(int l);
    std::string levelName() const;

    void display() const;
    std::string serialize() const;
    void deserialize(const std::string& line);
    std::string typeName() const;
};

#endif
