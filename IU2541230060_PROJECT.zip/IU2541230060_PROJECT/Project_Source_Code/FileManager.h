#ifndef FILEMANAGER_H
#define FILEMANAGER_H

#include <string>

class NGO;

// Saves and loads the four data files (one record per line, '|' separated).
class FileManager {
private:
    std::string dir;                     // data folder, e.g. "Data"

    std::string path(const std::string& file) const;
    void makeDir() const;

public:
    explicit FileManager(const std::string& dir = "Data");
    ~FileManager();

    void save(NGO& ngo);                 // writes all four files
    bool load(NGO& ngo);                 // returns true if any file was found
};

#endif
