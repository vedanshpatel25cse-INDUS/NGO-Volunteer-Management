#include "Utils.h"
#include <iostream>
#include <cctype>
#include <cstdlib>

using namespace std;

string trim(const string& s) {
    size_t a = 0, b = s.size();
    while (a < b && isspace((unsigned char)s[a])) a++;
    while (b > a && isspace((unsigned char)s[b - 1])) b--;
    return s.substr(a, b - a);
}

string toLower(const string& s) {
    string r = s;
    for (size_t i = 0; i < r.size(); i++) r[i] = (char)tolower((unsigned char)r[i]);
    return r;
}

void validateText(const string& s, const string& what) {
    if (s.empty())
        throw ValidationException(what + " cannot be empty.");
    if (s.find('|') != string::npos)
        throw ValidationException("The '|' character is not allowed.");
}

void validateName(const string& s) {
    validateText(s, "Name");
    for (size_t i = 0; i < s.size(); i++) {
        char c = s[i];
        if (!isalpha((unsigned char)c) && c != ' ' && c != '.' && c != '-' && c != '\'')
            throw ValidationException("Name may contain only letters and spaces.");
    }
}

void validatePhone(const string& s) {
    if (s.size() != 10)
        throw ValidationException("Phone must be exactly 10 digits.");
    for (size_t i = 0; i < s.size(); i++)
        if (!isdigit((unsigned char)s[i]))
            throw ValidationException("Phone must be exactly 10 digits.");
}

void validateDate(const string& s) {
    // expected format DD/MM/YYYY
    if (s.size() != 10 || s[2] != '/' || s[5] != '/')
        throw ValidationException("Date must be in DD/MM/YYYY format.");
    for (size_t i = 0; i < s.size(); i++) {
        if (i == 2 || i == 5) continue;
        if (!isdigit((unsigned char)s[i]))
            throw ValidationException("Date must be in DD/MM/YYYY format.");
    }
    int d = atoi(s.substr(0, 2).c_str());
    int m = atoi(s.substr(3, 2).c_str());
    int y = atoi(s.substr(6, 4).c_str());
    if (y < 2000 || y > 2100) throw ValidationException("Year must be between 2000 and 2100.");
    if (m < 1 || m > 12)      throw ValidationException("Invalid date (month must be 1-12).");
    int days[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    bool leap = (y % 4 == 0 && y % 100 != 0) || (y % 400 == 0);
    if (leap) days[1] = 29;
    if (d < 1 || d > days[m - 1])
        throw ValidationException("Invalid date (day out of range for month).");
}

static void showInvalid(const string& msg) {
    cout << RED << "  [Invalid] " << msg << RESET << endl;
}

string readLine(const string& prompt) {
    string line;
    cout << prompt << flush;
    if (!getline(cin, line)) throw InputClosedException();
    return trim(line);
}

int readInt(const string& prompt, int lo, int hi) {
    while (true) {
        string s = readLine(prompt);
        try {
            if (s.empty() || s.size() > 6) throw ValidationException("Please enter a number.");
            for (size_t i = 0; i < s.size(); i++)
                if (!isdigit((unsigned char)s[i]))
                    throw ValidationException("Please enter a number.");
            int v = atoi(s.c_str());
            if (v < lo || v > hi) throw ValidationException("Choice must be between " +
                                      to_string(lo) + " and " + to_string(hi) + ".");
            return v;
        } catch (ValidationException& e) {
            showInvalid(e.what());
        }
    }
}

string readName(const string& prompt) {
    while (true) {
        string s = readLine(prompt);
        try { validateName(s); return s; }
        catch (ValidationException& e) { showInvalid(e.what()); }
    }
}

string readText(const string& prompt, const string& what) {
    while (true) {
        string s = readLine(prompt);
        try { validateText(s, what); return s; }
        catch (ValidationException& e) { showInvalid(e.what()); }
    }
}

string readPhone(const string& prompt) {
    while (true) {
        string s = readLine(prompt);
        try { validatePhone(s); return s; }
        catch (ValidationException& e) { showInvalid(e.what()); }
    }
}

string readDate(const string& prompt) {
    while (true) {
        string s = readLine(prompt);
        try { validateDate(s); return s; }
        catch (ValidationException& e) { showInvalid(e.what()); }
    }
}
