#ifndef VOLUNTEER_H
#define VOLUNTEER_H

#include "Record.h"

class Volunteer : public Record {
private:
    std::string phone;
    std::string skills;     // comma separated, e.g. "First Aid, Cooking"

public:
    Volunteer();
    Volunteer(int id, const std::string& name, const std::string& phone,
              const std::string& skills);
    ~Volunteer();

    const std::string& getPhone() const;
    const std::string& getSkills() const;
    void setPhone(const std::string& p);
    void setSkills(const std::string& s);

    void display() const;
    std::string serialize() const;
    void deserialize(const std::string& line);
    std::string typeName() const;
};

#endif
