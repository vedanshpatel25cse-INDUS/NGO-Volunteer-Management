#ifndef ASSIGNMENT_H
#define ASSIGNMENT_H

#include "Record.h"

// Links one volunteer to one event with a role.
// (Record::name is not used; the role is stored separately.)
class Assignment : public Record {
private:
    int volunteerId;
    int eventId;
    std::string role;

public:
    Assignment();
    Assignment(int id, int volunteerId, int eventId, const std::string& role);
    ~Assignment();

    void assign(int vId, int eId, const std::string& r);
    int getVolunteerId() const;
    int getEventId() const;
    const std::string& getRole() const;
    void setRole(const std::string& r);

    void display() const;
    std::string serialize() const;
    void deserialize(const std::string& line);
    std::string typeName() const;
};

#endif
