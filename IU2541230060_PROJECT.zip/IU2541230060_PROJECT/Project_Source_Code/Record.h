#ifndef RECORD_H
#define RECORD_H

#include <string>
#include <vector>

// Abstract base class: every entity has an id, a name and a
// polymorphic interface (display / serialize / deserialize).
class Record {
protected:
    int id;
    std::string name;

public:
    Record();
    Record(int id, const std::string& name);
    virtual ~Record();

    int getId() const;
    const std::string& getName() const;
    void setId(int newId);
    void setName(const std::string& newName);

    virtual void display() const = 0;
    virtual std::string serialize() const = 0;
    virtual void deserialize(const std::string& line) = 0;
    virtual std::string typeName() const = 0;

    // helper shared by all derived classes: split a line on '|'
    static std::vector<std::string> split(const std::string& line, char sep = '|');
};

#endif
