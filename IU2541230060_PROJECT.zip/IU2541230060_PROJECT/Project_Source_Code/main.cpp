#include "NGO.h"

int main() {
    NGO ngo;
    ngo.run();
    return 0;
}
