#include "Event.h"
#include "Utils.h"
#include <iostream>
#include <iomanip>
#include <cstdlib>
using namespace std;

Event::Event() : Record(), date("") {}
Event::Event(int id, const string& name, const string& date) : Record(id, name), date(date) {}
Event::~Event() {}

const string& Event::getDate() const { return date; }
void Event::setDate(const string& d) { date = d; }

void Event::display() const {
    cout << "  ID: " << left << setw(3) << id
         << " | Event: " << setw(24) << name
         << " | Date: " << date << endl;
}

string Event::serialize() const {
    return to_string(id) + "|" + name + "|" + date;
}

void Event::deserialize(const string& line) {
    vector<string> p = split(line);
    if (p.size() != 3) throw AppException("Corrupt event record");
    id = atoi(p[0].c_str());
    name = p[1];
    date = p[2];
    if (id <= 0) throw AppException("Corrupt event record (bad id)");
    try { validateDate(date); }
    catch (ValidationException&) { throw AppException("Corrupt event record (bad date)"); }
}

string Event::typeName() const { return "Event"; }
