#include "Volunteer.h"
#include "Utils.h"
#include <iostream>
#include <iomanip>
#include <cstdlib>
using namespace std;

Volunteer::Volunteer() : Record(), phone(""), skills("") {}
Volunteer::Volunteer(int id, const string& name, const string& phone, const string& skills)
    : Record(id, name), phone(phone), skills(skills) {}
Volunteer::~Volunteer() {}

const string& Volunteer::getPhone() const  { return phone; }
const string& Volunteer::getSkills() const { return skills; }
void Volunteer::setPhone(const string& p)  { phone = p; }
void Volunteer::setSkills(const string& s) { skills = s; }

void Volunteer::display() const {
    cout << "  ID: " << left << setw(3) << id
         << " | Name: " << setw(18) << name
         << " | Phone: " << phone
         << " | Skills: " << skills << endl;
}

string Volunteer::serialize() const {
    return to_string(id) + "|" + name + "|" + phone + "|" + skills;
}

void Volunteer::deserialize(const string& line) {
    vector<string> p = split(line);
    if (p.size() != 4) throw AppException("Corrupt volunteer record");
    id = atoi(p[0].c_str());
    name = p[1];
    phone = p[2];
    skills = p[3];
    if (id <= 0) throw AppException("Corrupt volunteer record (bad id)");
}

string Volunteer::typeName() const { return "Volunteer"; }
