@echo off
g++ -std=c++11 -Wall -Wextra main.cpp NGO.cpp FileManager.cpp Record.cpp Volunteer.cpp Event.cpp Skill.cpp Assignment.cpp Utils.cpp -o NGOVolunteer.exe
if errorlevel 1 (echo Build failed.) else (echo Built NGOVolunteer.exe)
pause
